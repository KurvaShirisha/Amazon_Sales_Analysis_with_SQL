-------------------------------------- SQL CAPSTONE PROJECT --------------------------------------------
------ AMAZON DATASET ---------
-- Data Wrangling
-- 1. Building DataBase

CREATE DATABASE amazon;
use amazon;

-- 2. Table creation and data insertion having no null values

CREATE TABLE amazon (
Invoice_Id varchar(30) NOT NULL,
Branch varchar(5) NOT NULL,
City varchar(30) NOT NULL,
Customer_type varchar(30) NOT NULL,
Gender varchar(10) NOT NULL,
Product_line varchar(100) NOT NULL,
Unit_price decimal(10,2) NOT NULL,
Quantity int NOT NULL,
VAT float NOT NULL,
Total decimal(10,2) NOT NULL,
Date date NOT NULL,
Time time NOT NULL,
Payment varchar(50) NOT NULL,
Cogs decimal(10,2) NOT NULL,
gross_margin_percentage float NOT NULL,
gross_income decimal(10,2) NOT NULL,
Rating float NOT NULL
);

SELECT  * FROM amazon;

-- Feature Engineering
-- 1. Adding new column named timeofday to give insight of sales in the Morning,Afternon and Evening.

ALTER TABLE amazon                                   # ALTER is part od DDL Comand
ADD COLUMN time_of_day varchar(50);                  # New column created name time_of_day

SET SQL_SAFE_UPDATES =0;

UPDATE amazon
SET time_of_day = CASE
	WHEN HOUR(amazon.Time) >= 0 AND HOUR(amazon.Time) < 12 THEN 'Morning'
    WHEN HOUR(amazon.Time) >= 12 AND HOUR(amazon.Time) < 18 THEN 'Afternoon'
    ELSE 'Evening'
End;

SET SQL_SAFE_UPDATES = 1;

-- 2. Adding new column named dayname that contains the extracted days of the week on which the given transaction took place

ALTER TABLE amazon                           # created new column 'day_name'
ADD COLUMN day_name varchar(50);

SET SQL_SAFE_UPDATES =0;

UPDATE amazon
SET day_name =DATE_FORMAT(amazon.Date,'%a');  # column dayname updated with date_format method of mysql to get weekdays names

SET SQL_SAFE_UPDATES = 1;

-- 3. Adding  a new column named monthname that contains the extracted months of the year on which the given transaction took place.

ALTER TABLE amazon                           # created new column as month_name
ADD COLUMN month_name varchar(50);

SET SQL_SAFE_UPDATES =0;

UPDATE amazon
SET month_name = DATE_FORMAT(amazon.Date,'%b');  # column monthname updated to get first three letters of months.

SET SQL_SAFE_UPDATES = 1;

SELECT * FROM amazon;

---------- BUSINESS QUESTIONS TO ANSWER: ---------------

---- 1. what is the count of distinct cities in the dataset?

SELECT COUNT(DISTINCT City) AS city_count
FROM amazon;

-- There are 3 distinct cities, there are Mandalay,Naypyitaw,Yangon

---- 2. For each branch,what is the corresponding city?

SELECT distinct Branch,City
FROM amazon;

-- In dataset, there are 3 unique branches are Branch A consists of city 'Yangon',Branch B city is 'Mandalay' and Branch C consists city 'Naypitaw' .

---- 3. What is the count of distinct product lines in the dataset ?

SELECT COUNT(DISTINCT Product_line) AS distinct_product_line
FROM amazon;

-- There are 6 Distinct product line are there in given dataset.

---- 4. Which payment method occurs most frequently?

SELECT max(Payment) as most_occur_payment
FROM amazon;

-- Ewallet payment method has more number of trancations are occur compared to others payment method.

---- 5.Which product line has the highest Sales ?

SELECT Product_line, SUM(gross_income) AS Highest_sales
FROM amazon
GROUP BY Product_line
ORDER BY Highest_sales DESC;

-- Food and beverages of product line have highest sales compared to others.

---- 6. How much revenue is generated each month ?

SELECT month_name,sum(Total) AS monthly_revenue
FROM amazon
GROUP BY month_name
ORDER BY monthly_revenue desc;

-- January month received highest monthly_revenue among all three months.

---- 7.In which month did the cost of goods sold reach its peak?

SELECT month_name,max(Cogs) as max_cogs
FROM amazon
GROUP BY month_name
ORDER BY max_cogs desc;

-- cost of goods reached its peaks in the month of february and followed by january,march.

---- 8. Which product line generated the highest revenue ?

SELECT Product_line,sum(Total) AS Highest_revenue
FROM amazon
GROUP BY Product_line
ORDER BY Highest_revenue desc;

-- out of 6 product line,food and beverages received the highest revenue in total. 

---- 9. In which city was the highest revenue recorded?

SELECT City,sum(Total) AS Highest_revenue
FROM amazon
GROUP BY City
ORDER BY Highest_revenue desc;

-- out of 3 cities in the dataset, Naypyitaw recieved highest total revenue.

---- 10. Which product line incurred the highest value added tax?

SELECT Product_line,sum(VAT) as high_vat
FROM amazon
GROUP BY Product_line
ORDER BY high_vat desc;

-- Food and beverages of product line have highest value added tax.

---- 11. For each product line, add a column indicating 'Good' if its sales are above average. otherwise 'Bad'?

SELECT Product_line,
CASE
WHEN gross_income > (select avg(gross_income) from amazon) THEN 'Good'
ELSE 'Bad'
END AS sales_performance
FROM amazon;

-- Almost all product lines of sales are more than average sales its means performance of product id 'Good'.

---- 12. Identity the branch that exceeded the average number of products sold?

SELECT DISTINCT Branch
FROM amazon
WHERE Quantity > (
				   SELECT AVG(Quantity)
                   FROM amazon
				  );

-- All three brnches have exceeded the avg number of product sold.

---- 13. Which product line is most frequently associated with each gender?

SELECT Gender, Product_line, COUNT(*) AS frequency
FROM amazon
GROUP BY Gender, Product_line
ORDER BY Gender, frequency DESC;

-- The Female gender most frequently associated with product line of 'Health and beauty'.

---- 14. Calculate the average rating for each product line?

SELECT Product_line,avg(Rating) as average_rating
FROM amazon
GROUP BY Product_line;

-- Food and beverages get the highest average rating followed by Fashion accessories.

---- 15. Count the sales occurrences for each time of day on every weekday?

SELECT day_name,time_of_day,count(*) AS sales_occur
FROM amazon
GROUP BY day_name,time_of_day
ORDER BY sales_occur desc;

-- At sat and wed day afternoon recieved high sales compared tom other week days in dataset.

---- 16. Identify the customer type contributing the highest revenue?

SELECT Customer_type,sum(Total) AS highest_revenue
FROM amazon
GROUP BY Customer_type
ORDER BY highest_revenue DESC;

-- out of two customer type,Member customers have highest revenue.

---- 17.Determine the city with the highest VAT percentage?

SELECT City,(sum(VAT)/sum(Total))*100 AS vat_percentage
FROM amazon
GROUP BY  City
ORDER BY vat_percentage DESC;

-- among 3 cities, Naypyitaw city have highest vat percentage .

---- 18. Identify the customer type with the highest VAT payments?

SELECT Customer_type,SUM(VAT) AS high_vat
FROM amazon
GROUP BY Customer_type
ORDER BY high_vat DESC;

-- Member customers contributes maximum to the revenue compare to Normal.

---- 19. What is the count of distinct customer types in the dataset?

SELECT COUNT(DISTINCT Customer_type) AS customer_type_count
FROM amazon;

-- There are two types of customer type in the dataset - Member and Normal customers.

---- 20. What is the count of distinct payment methods in the dataset?

SELECT COUNT(DISTINCT Payment) AS payment_method_count
FROM amazon;

-- There are 3 distinct types of payment methods - Ewallet,Cash and Credit Card.

---- 21. Which customer type occurs most frequently?

SELECT Customer_type,COUNT(*) AS most_freq
FROM amazon
GROUP BY Customer_type;

-- Member type customer occurs to purchase more frequently.

---- 22. Identify the customer type width the highest purchase frequency?

SELECT Customer_type,sum(Quantity) AS high_purchase_frequency
FROM amazon
GROUP BY Customer_type
ORDER BY high_purchase_frequency DESC;

-- Member customer type purchase goods more frequently.

---- 23. Determine the predominant gender among customers?

SELECT Gender,count(*) AS customer_count
FROM amazon
GROUP BY Gender
ORDER BY customer_count DESC;

-- Female contributes more than male.

---- 24. Examine the distribution of genders within each branch

SELECT Branch,Gender,count(Gender) AS gender_distribution
FROM amazon
GROUP BY Branch,Gender
ORDER BY Branch,gender_distribution DESC;

-- Branch A and B have more female and Branch C have more Male .

---- 25. Identify the time of day when customers provide the most ratings?

SELECT time_of_day,count(Rating) AS rating_count
FROM amazon
GROUP BY time_of_day
ORDER BY rating_count DESC;

-- Most number of ratings are provided during afternoon.

---- 26. Determine the time of day with the highest customer ratings for each branch?

SELECT Branch,time_of_day,count(Rating) AS rating_count
FROM amazon
GROUP BY Branch,time_of_day
ORDER BY Branch;

-- all the three branches afternoon is the time when they get their most number of ratings

---- 27. Identify the day of the week with the highest average ratings.

SELECT day_name,avg(Rating) AS avg_rating
FROM amazon
GROUP BY day_name
ORDER BY avg_rating DESC
limit 3;

-- all the weekdays.Monday is the day when highest avgerage rating received.

---- 28. Determine the day of the week with the highest average ratings for each branch?

WITH avg_ratings_per_day AS (
    SELECT 
        Branch,
        day_name,
        AVG(Rating) AS average_rating,
        ROW_NUMBER() OVER (PARTITION BY Branch ORDER BY AVG(Rating) DESC) AS row_num
    FROM 
        amazon
    GROUP BY 
        Branch, day_name
)
SELECT 
    Branch,
    day_name,
    average_rating
FROM 
    avg_ratings_per_day
WHERE 
    row_num = 1;

-- on Friday Branch A and C recived more rating compared to other weekdays and Monday Branch B have more ratings.

-------------- CONCLUSION -----------------
-- Product Analysis:
-- 1. There are 6 different product lines are available under the table Amazon data. Out of 6 products, Food and beverages generating highest Revenue. 
-- 2. Food and beverages generating highest Sales. 

-- Sales Analysis :
-- 1. Among all the 3 cities Napyitaw city generates highest revenue and also having highest purchasing in this location. 
-- 2. Most of the customers are preferring the "Ewallet" payment method to make more digital transactions. 
-- 3. The customer type "Member" is generates more revenue.

-- Customer Analysis:
-- 1. Based on the gender that is male and female, Female customers are more dominating than male customers in relsults for generating the income. 
-- 2. In relation to branch wise sales male customers under branch A and B are more compared to female customers and female customers more sales in branch C . 
-- 3. Most of the ratings are more in "Afternoon" time across all the branches and customers are actively giving ratings at affternoo time. 

--------------------------------------------------------------------------------------------------------------------------------------------------------
########################################################################## END #############################################################################
